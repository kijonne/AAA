﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LabWork41
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isMenuOpen = true;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Анимация для задания 5.2
            DoubleAnimation textAnimation = new DoubleAnimation
            {
                From = 14,
                To = 28,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };
            AnimatedButton.FontSize = 14;
            AnimatedButton.BeginAnimation(Button.FontSizeProperty, textAnimation);

            // Анимация для задания 5.3
            DoubleAnimation complexTextAnimation = new DoubleAnimation
            {
                From = 14,
                To = 28,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };

            DoubleAnimation widthAnimation = new DoubleAnimation
            {
                From = 150,
                To = 300,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };

            DoubleAnimation heightAnimation = new DoubleAnimation
            {
                From = 50,
                To = 100,
                Duration = TimeSpan.FromSeconds(1),
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(2)
            };

            ComplexAnimatedButton.BeginAnimation(Button.FontSizeProperty, complexTextAnimation);
            ComplexAnimatedButton.BeginAnimation(Button.WidthProperty, widthAnimation);
            ComplexAnimatedButton.BeginAnimation(Button.HeightProperty, heightAnimation);
        }

        private void HamburgerButton_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation animation = new DoubleAnimation
            {
                Duration = TimeSpan.FromSeconds(1),
                To = isMenuOpen ? 0 : 200
            };

            SideMenu.BeginAnimation(Border.WidthProperty, animation);
            isMenuOpen = !isMenuOpen;
        }

        private void ChangeColor_Click(object sender, RoutedEventArgs e)
        {
            ColorAnimationUsingKeyFrames animation = new ColorAnimationUsingKeyFrames
            {
                Duration = TimeSpan.FromSeconds(2.5)
            };

            animation.KeyFrames.Add(new LinearColorKeyFrame(Colors.Red, KeyTime.FromPercent(0)));
            animation.KeyFrames.Add(new LinearColorKeyFrame(Colors.Yellow, KeyTime.FromPercent(0.25)));
            animation.KeyFrames.Add(new LinearColorKeyFrame(Colors.Green, KeyTime.FromPercent(0.5)));
            animation.KeyFrames.Add(new LinearColorKeyFrame(Colors.Blue, KeyTime.FromPercent(0.75)));
            animation.KeyFrames.Add(new LinearColorKeyFrame(Colors.Purple, KeyTime.FromPercent(1)));

            CircleGradient.GradientStops[0].BeginAnimation(GradientStop.ColorProperty, animation);

            ColorAnimationUsingKeyFrames animation2 = new ColorAnimationUsingKeyFrames
            {
                Duration = TimeSpan.FromSeconds(2.5)
            };

            animation2.KeyFrames.Add(new LinearColorKeyFrame(Colors.Blue, KeyTime.FromPercent(0)));
            animation2.KeyFrames.Add(new LinearColorKeyFrame(Colors.Purple, KeyTime.FromPercent(0.25)));
            animation2.KeyFrames.Add(new LinearColorKeyFrame(Colors.Red, KeyTime.FromPercent(0.5)));
            animation2.KeyFrames.Add(new LinearColorKeyFrame(Colors.Yellow, KeyTime.FromPercent(0.75)));
            animation2.KeyFrames.Add(new LinearColorKeyFrame(Colors.Green, KeyTime.FromPercent(1)));

            CircleGradient.GradientStops[1].BeginAnimation(GradientStop.ColorProperty, animation2);
        }
        }
    }
